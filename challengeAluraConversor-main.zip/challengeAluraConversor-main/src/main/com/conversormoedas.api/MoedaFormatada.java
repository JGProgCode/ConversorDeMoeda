package main.com.conversormoedas.api;


public record MoedaFormatada(double conversion_rate) {


}
