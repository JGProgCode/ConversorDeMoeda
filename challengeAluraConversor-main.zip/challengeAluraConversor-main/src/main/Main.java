package main;

import main.com.UI.UIOp;
import main.com.conversormoedas.api.CurrencyConverterService;
import com.google.gson.Gson;


import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {
        System.setProperty("file.encoding", "UTF-8");
        UIOp.inicio();


        }
    }